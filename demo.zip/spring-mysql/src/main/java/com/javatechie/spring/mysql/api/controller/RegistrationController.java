package com.javatechie.spring.mysql.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javatechie.spring.mysql.api.dao.RegistrationDao;
import com.javatechie.spring.mysql.api.model.Registration;


@RestController
@RequestMapping("/ticket")
public class RegistrationController {
	@Autowired
	private RegistrationDao dao;
	
	@Autowired
	Environment environment;

	@PostMapping("/bookTickets")
	public ResponseEntity<String> bookTicket(@RequestBody Registration registration) {
		dao.save(registration);
		ResponseEntity<String> response= new ResponseEntity<String>
		(environment.getProperty("API.REGISTRATION_SUCCESSFUL")+ registration.getId()
				, HttpStatus.CREATED);
		return response;
		//return "ticket booked : " + tickets.size();
	}

	@GetMapping("/getTickets")
	public List<Registration> getTickets() {
		return (List<Registration>) dao.findAll();
	}

}
