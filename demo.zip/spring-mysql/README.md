# Spring-boot-mysql
How to configure mysql with  spring boot
